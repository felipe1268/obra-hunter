import { useState, useEffect, useCallback } from "react";
import {
  Search, Building2, MapPin, TrendingUp, Bell, Settings,
  ChevronRight, ExternalLink, Linkedin, Phone, Mail,
  CheckCircle, XCircle, Clock, Play, Pause, RefreshCw,
  Filter, BarChart3, Target, Zap, Globe, FileText,
  AlertTriangle, ArrowUpRight, Eye, UserCheck, X,
  ChevronDown, Activity, Layers, Calendar, Star
} from "lucide-react";

// ==================== MOCK DATA ====================
const MOCK_STATS = {
  total_obras: 1247,
  obras_novas_hoje: 23,
  obras_novas_semana: 156,
  total_empresas: 489,
  total_decisores: 312,
  decisores_validados: 87,
  buscas_ativas: 4,
  alertas_hoje: 7,
  score_medio: 6.4,
  obras_por_status: { novo: 580, enriquecido: 340, contato_encontrado: 180, em_prospeccao: 89, convertido: 34, descartado: 24 },
  obras_por_tipo: { residencial: 520, comercial: 310, industrial: 145, infraestrutura: 172, institucional: 68, loteamento: 32 },
  obras_por_estado: { SP: 380, RJ: 195, MG: 148, PR: 95, SC: 82, RS: 78, BA: 72, GO: 58, PE: 52, CE: 47 },
  obras_por_fonte: { google_maps: 420, diario_oficial: 380, licitacao: 290, construtora: 157 },
  timeline_semanal: [
    { data: "02/03", dia_semana: "dom", obras: 12 },
    { data: "03/03", dia_semana: "seg", obras: 28 },
    { data: "04/03", dia_semana: "ter", obras: 34 },
    { data: "05/03", dia_semana: "qua", obras: 22 },
    { data: "06/03", dia_semana: "qui", obras: 31 },
    { data: "07/03", dia_semana: "sex", obras: 19 },
    { data: "08/03", dia_semana: "sáb", obras: 23 },
  ],
};

const MOCK_OBRAS = [
  { id: 1, titulo: "Edifício Corporate Plaza - Torre Sul", cidade: "São Paulo", estado: "SP", tipo: "comercial", fase: "fundacao", porte: "grande", score_oportunidade: 9.2, status: "novo", fonte: "google_maps", data_encontrada: "2025-03-08T10:30:00", empresa_nome: "Cyrela Brazil Realty", area_m2: 12000, valor_estimado: 45000000 },
  { id: 2, titulo: "Condomínio Parque das Águas - Fase 2", cidade: "Campinas", estado: "SP", tipo: "residencial", fase: "estrutura", porte: "grande", score_oportunidade: 8.7, status: "enriquecido", fonte: "construtora", data_encontrada: "2025-03-08T08:15:00", empresa_nome: "MRV Engenharia", area_m2: 8500, valor_estimado: 32000000 },
  { id: 3, titulo: "Centro Logístico Dutra - Galpões A-D", cidade: "Guarulhos", estado: "SP", tipo: "industrial", fase: "aprovacao", porte: "grande", score_oportunidade: 8.5, status: "novo", fonte: "diario_oficial", data_encontrada: "2025-03-07T16:45:00", empresa_nome: "GLP Capital Partners", area_m2: 22000, valor_estimado: 65000000 },
  { id: 4, titulo: "Hospital Regional Norte Fluminense", cidade: "Campos dos Goytacazes", estado: "RJ", tipo: "institucional", fase: "fundacao", porte: "grande", score_oportunidade: 8.1, status: "contato_encontrado", fonte: "licitacao", data_encontrada: "2025-03-07T14:20:00", empresa_nome: "Governo do Estado RJ", area_m2: 6000, valor_estimado: 28000000 },
  { id: 5, titulo: "Residencial Vista Bela - 3 Torres", cidade: "Belo Horizonte", estado: "MG", tipo: "residencial", fase: "aprovacao", porte: "medio", score_oportunidade: 7.8, status: "novo", fonte: "construtora", data_encontrada: "2025-03-07T11:00:00", empresa_nome: "Direcional Engenharia", area_m2: 4200, valor_estimado: 18000000 },
  { id: 6, titulo: "Pavimentação BR-101 - Trecho Joinville", cidade: "Joinville", estado: "SC", tipo: "infraestrutura", fase: "estrutura", porte: "grande", score_oportunidade: 7.5, status: "enriquecido", fonte: "licitacao", data_encontrada: "2025-03-06T09:30:00", empresa_nome: "DNIT", area_m2: null, valor_estimado: 42000000 },
  { id: 7, titulo: "Shopping Center Vida Nova", cidade: "Curitiba", estado: "PR", tipo: "comercial", fase: "fundacao", porte: "grande", score_oportunidade: 9.0, status: "novo", fonte: "google_maps", data_encontrada: "2025-03-08T07:00:00", empresa_nome: "Multiplan", area_m2: 35000, valor_estimado: 120000000 },
  { id: 8, titulo: "Loteamento Eco Park - 200 lotes", cidade: "Ribeirão Preto", estado: "SP", tipo: "loteamento", fase: "aprovacao", porte: "medio", score_oportunidade: 7.2, status: "novo", fonte: "diario_oficial", data_encontrada: "2025-03-06T15:10:00", empresa_nome: "Alphaville Urbanismo", area_m2: 180000, valor_estimado: 25000000 },
];

const MOCK_ALERTAS = [
  { id: 1, titulo: "Shopping Center Vida Nova", score: 9.0, motivo: "Obra comercial grande porte • Fase fundação • R$ 120M", cidade: "Curitiba - PR", tempo: "1h atrás" },
  { id: 2, titulo: "Edifício Corporate Plaza", score: 9.2, motivo: "Obra comercial grande porte • Fase fundação • R$ 45M", cidade: "São Paulo - SP", tempo: "2h atrás" },
  { id: 3, titulo: "Condomínio Parque das Águas", score: 8.7, motivo: "Obra residencial grande porte • Em construção • R$ 32M", cidade: "Campinas - SP", tempo: "4h atrás" },
  { id: 4, titulo: "Centro Logístico Dutra", score: 8.5, motivo: "Obra industrial grande porte • Alvará publicado • R$ 65M", cidade: "Guarulhos - SP", tempo: "5h atrás" },
];

const MOCK_BUSCAS = [
  { id: 1, nome: "Obras Comerciais SP/RJ", ativa: true, frequencia: "continua", ultima_execucao: "2025-03-08T10:30:00", total_obras_encontradas: 342, total_alertas_enviados: 28, filtros: { estados: ["SP", "RJ"], tipos: ["comercial"] } },
  { id: 2, nome: "Licitações Infraestrutura Brasil", ativa: true, frequencia: "diaria", ultima_execucao: "2025-03-08T06:00:00", total_obras_encontradas: 189, total_alertas_enviados: 15, filtros: { tipos: ["infraestrutura"], fontes: ["licitacao"] } },
  { id: 3, nome: "Residencial Grande Porte Sul", ativa: true, frequencia: "diaria", ultima_execucao: "2025-03-08T06:00:00", total_obras_encontradas: 267, total_alertas_enviados: 22, filtros: { estados: ["PR", "SC", "RS"], tipos: ["residencial"], portes: ["grande"] } },
  { id: 4, nome: "Industrial Nacional", ativa: false, frequencia: "semanal", ultima_execucao: "2025-03-03T06:00:00", total_obras_encontradas: 95, total_alertas_enviados: 8, filtros: { tipos: ["industrial"] } },
];

// ==================== HELPERS ====================
const formatCurrency = (v) => v ? `R$ ${(v / 1e6).toFixed(1)}M` : "—";
const formatNumber = (n) => n?.toLocaleString("pt-BR") || "0";
const formatDate = (d) => d ? new Date(d).toLocaleDateString("pt-BR") : "—";

const TIPO_COLORS = {
  residencial: { bg: "bg-blue-500/10", text: "text-blue-400", border: "border-blue-500/30" },
  comercial: { bg: "bg-amber-500/10", text: "text-amber-400", border: "border-amber-500/30" },
  industrial: { bg: "bg-purple-500/10", text: "text-purple-400", border: "border-purple-500/30" },
  infraestrutura: { bg: "bg-emerald-500/10", text: "text-emerald-400", border: "border-emerald-500/30" },
  institucional: { bg: "bg-rose-500/10", text: "text-rose-400", border: "border-rose-500/30" },
  loteamento: { bg: "bg-cyan-500/10", text: "text-cyan-400", border: "border-cyan-500/30" },
};

const FONTE_ICONS = { google_maps: Globe, diario_oficial: FileText, licitacao: Target, construtora: Building2 };
const STATUS_LABELS = { novo: "Novo", enriquecido: "Enriquecido", contato_encontrado: "Contato", em_prospeccao: "Prospectando", contatado: "Contatado", em_negociacao: "Negociando", convertido: "Convertido", descartado: "Descartado" };
const STATUS_COLORS = { novo: "bg-slate-500", enriquecido: "bg-blue-500", contato_encontrado: "bg-indigo-500", em_prospeccao: "bg-amber-500", contatado: "bg-orange-500", em_negociacao: "bg-purple-500", convertido: "bg-emerald-500", descartado: "bg-red-500" };

function ScoreBadge({ score, size = "md" }) {
  const color = score >= 8.5 ? "from-red-500 to-orange-500" : score >= 7 ? "from-amber-500 to-yellow-500" : score >= 5 ? "from-blue-500 to-cyan-500" : "from-slate-500 to-gray-500";
  const sz = size === "lg" ? "w-14 h-14 text-lg" : size === "sm" ? "w-8 h-8 text-xs" : "w-10 h-10 text-sm";
  return (
    <div className={`${sz} rounded-xl bg-gradient-to-br ${color} flex items-center justify-center font-bold text-white shadow-lg`}>
      {score.toFixed(1)}
    </div>
  );
}

// ==================== COMPONENTS ====================

function StatCard({ icon: Icon, label, value, sub, accent = false }) {
  return (
    <div className={`relative overflow-hidden rounded-2xl p-5 ${accent ? "bg-gradient-to-br from-amber-500/20 to-orange-600/10 border border-amber-500/20" : "bg-[#1a1f35]/80 border border-white/5"}`}>
      <div className="flex items-start justify-between">
        <div>
          <p className="text-xs uppercase tracking-wider text-slate-400 mb-1">{label}</p>
          <p className={`text-2xl font-bold ${accent ? "text-amber-400" : "text-white"}`}>{value}</p>
          {sub && <p className="text-xs text-slate-500 mt-1">{sub}</p>}
        </div>
        <div className={`p-2.5 rounded-xl ${accent ? "bg-amber-500/20" : "bg-white/5"}`}>
          <Icon size={20} className={accent ? "text-amber-400" : "text-slate-400"} />
        </div>
      </div>
    </div>
  );
}

function MiniChart({ data }) {
  const max = Math.max(...data.map((d) => d.obras));
  return (
    <div className="flex items-end gap-1.5 h-16">
      {data.map((d, i) => (
        <div key={i} className="flex flex-col items-center gap-1 flex-1">
          <div
            className="w-full rounded-md bg-gradient-to-t from-cyan-500 to-cyan-400 min-h-[4px] transition-all"
            style={{ height: `${(d.obras / max) * 100}%`, opacity: 0.4 + (d.obras / max) * 0.6 }}
          />
          <span className="text-[9px] text-slate-500">{d.dia_semana}</span>
        </div>
      ))}
    </div>
  );
}

function ObraCard({ obra, onClick }) {
  const tipoStyle = TIPO_COLORS[obra.tipo] || TIPO_COLORS.residencial;
  const FonteIcon = FONTE_ICONS[obra.fonte] || Globe;

  return (
    <div
      onClick={() => onClick?.(obra)}
      className="group relative bg-[#1a1f35]/80 border border-white/5 rounded-2xl p-5 hover:border-cyan-500/30 transition-all cursor-pointer hover:shadow-lg hover:shadow-cyan-500/5"
    >
      <div className="flex gap-4">
        <ScoreBadge score={obra.score_oportunidade} />
        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-2">
            <h3 className="text-white font-semibold text-sm leading-tight truncate group-hover:text-cyan-400 transition-colors">
              {obra.titulo}
            </h3>
            <ArrowUpRight size={14} className="text-slate-600 group-hover:text-cyan-400 transition-colors flex-shrink-0 mt-0.5" />
          </div>
          <div className="flex items-center gap-2 mt-1.5 flex-wrap">
            <span className="flex items-center gap-1 text-xs text-slate-400">
              <MapPin size={11} /> {obra.cidade} - {obra.estado}
            </span>
            <span className={`text-[10px] px-2 py-0.5 rounded-full border ${tipoStyle.bg} ${tipoStyle.text} ${tipoStyle.border}`}>
              {obra.tipo}
            </span>
            <span className={`text-[10px] px-2 py-0.5 rounded-full ${STATUS_COLORS[obra.status]} text-white`}>
              {STATUS_LABELS[obra.status]}
            </span>
          </div>
          <div className="flex items-center gap-3 mt-2 text-xs text-slate-500">
            {obra.empresa_nome && <span className="flex items-center gap-1"><Building2 size={10} /> {obra.empresa_nome}</span>}
            {obra.valor_estimado && <span className="font-medium text-emerald-400">{formatCurrency(obra.valor_estimado)}</span>}
            {obra.area_m2 && <span>{formatNumber(obra.area_m2)} m²</span>}
            <span className="flex items-center gap-1 ml-auto"><FonteIcon size={10} /> {obra.fonte.replace("_", " ")}</span>
          </div>
        </div>
      </div>
    </div>
  );
}

function AlertCard({ alerta }) {
  return (
    <div className="flex items-start gap-3 p-3 rounded-xl bg-amber-500/5 border border-amber-500/10 hover:border-amber-500/30 transition-all cursor-pointer">
      <ScoreBadge score={alerta.score} size="sm" />
      <div className="flex-1 min-w-0">
        <p className="text-sm text-white font-medium truncate">{alerta.titulo}</p>
        <p className="text-[11px] text-slate-400 mt-0.5">{alerta.motivo}</p>
        <div className="flex items-center justify-between mt-1">
          <span className="text-[10px] text-slate-500">{alerta.cidade}</span>
          <span className="text-[10px] text-slate-600">{alerta.tempo}</span>
        </div>
      </div>
    </div>
  );
}

function BuscaCard({ busca }) {
  return (
    <div className={`rounded-2xl p-5 border transition-all ${busca.ativa ? "bg-[#1a1f35]/80 border-emerald-500/20" : "bg-[#1a1f35]/40 border-white/5 opacity-60"}`}>
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <div className={`w-2 h-2 rounded-full ${busca.ativa ? "bg-emerald-400 animate-pulse" : "bg-slate-600"}`} />
          <h3 className="text-white font-semibold text-sm">{busca.nome}</h3>
        </div>
        <button className={`p-1.5 rounded-lg ${busca.ativa ? "bg-emerald-500/10 text-emerald-400" : "bg-slate-700 text-slate-400"}`}>
          {busca.ativa ? <Pause size={14} /> : <Play size={14} />}
        </button>
      </div>
      <div className="grid grid-cols-3 gap-3 text-center">
        <div>
          <p className="text-lg font-bold text-white">{formatNumber(busca.total_obras_encontradas)}</p>
          <p className="text-[10px] text-slate-500">Obras</p>
        </div>
        <div>
          <p className="text-lg font-bold text-amber-400">{busca.total_alertas_enviados}</p>
          <p className="text-[10px] text-slate-500">Alertas</p>
        </div>
        <div>
          <p className="text-[10px] text-slate-400 leading-relaxed mt-1">
            {busca.frequencia === "continua" ? "A cada 30min" : busca.frequencia === "diaria" ? "1x/dia" : "1x/semana"}
          </p>
          <p className="text-[10px] text-slate-500">Frequência</p>
        </div>
      </div>
      <div className="flex flex-wrap gap-1 mt-3">
        {busca.filtros.estados?.map((e) => (
          <span key={e} className="text-[9px] px-1.5 py-0.5 rounded bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">{e}</span>
        ))}
        {busca.filtros.tipos?.map((t) => (
          <span key={t} className="text-[9px] px-1.5 py-0.5 rounded bg-purple-500/10 text-purple-400 border border-purple-500/20">{t}</span>
        ))}
      </div>
      <p className="text-[10px] text-slate-600 mt-2">Última: {formatDate(busca.ultima_execucao)}</p>
    </div>
  );
}

function FunnelBar({ data }) {
  const stages = [
    { key: "novo", label: "Novo", color: "bg-slate-500" },
    { key: "enriquecido", label: "Enriquecido", color: "bg-blue-500" },
    { key: "contato_encontrado", label: "Contato", color: "bg-indigo-500" },
    { key: "em_prospeccao", label: "Prospectando", color: "bg-amber-500" },
    { key: "convertido", label: "Convertido", color: "bg-emerald-500" },
  ];
  const maxVal = Math.max(...stages.map((s) => data[s.key] || 0));

  return (
    <div className="space-y-2.5">
      {stages.map((s) => {
        const val = data[s.key] || 0;
        const pct = maxVal > 0 ? (val / maxVal) * 100 : 0;
        return (
          <div key={s.key} className="flex items-center gap-3">
            <span className="text-[11px] text-slate-400 w-20 text-right">{s.label}</span>
            <div className="flex-1 h-5 bg-white/5 rounded-full overflow-hidden">
              <div className={`h-full ${s.color} rounded-full transition-all`} style={{ width: `${pct}%` }} />
            </div>
            <span className="text-xs text-white font-medium w-10">{val}</span>
          </div>
        );
      })}
    </div>
  );
}

function SourceBreakdown({ data }) {
  const total = Object.values(data).reduce((a, b) => a + b, 0);
  const sources = [
    { key: "google_maps", label: "Google Maps", icon: Globe, color: "bg-cyan-500" },
    { key: "diario_oficial", label: "Diários Oficiais", icon: FileText, color: "bg-amber-500" },
    { key: "licitacao", label: "Licitações", icon: Target, color: "bg-purple-500" },
    { key: "construtora", label: "Construtoras", icon: Building2, color: "bg-emerald-500" },
  ];

  return (
    <div className="space-y-3">
      {sources.map((s) => {
        const val = data[s.key] || 0;
        const pct = total > 0 ? (val / total) * 100 : 0;
        return (
          <div key={s.key} className="flex items-center gap-3">
            <div className="p-1.5 rounded-lg bg-white/5">
              <s.icon size={14} className="text-slate-400" />
            </div>
            <div className="flex-1">
              <div className="flex justify-between mb-1">
                <span className="text-xs text-slate-300">{s.label}</span>
                <span className="text-xs text-slate-500">{val} ({pct.toFixed(0)}%)</span>
              </div>
              <div className="h-1.5 bg-white/5 rounded-full overflow-hidden">
                <div className={`h-full ${s.color} rounded-full`} style={{ width: `${pct}%` }} />
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}

function StateMap({ data }) {
  const entries = Object.entries(data).sort((a, b) => b[1] - a[1]);
  const max = entries[0]?.[1] || 1;

  return (
    <div className="grid grid-cols-5 gap-2">
      {entries.map(([estado, count]) => {
        const intensity = count / max;
        return (
          <div
            key={estado}
            className="flex flex-col items-center justify-center p-2 rounded-lg border border-white/5 hover:border-cyan-500/30 transition-all cursor-pointer"
            style={{ background: `rgba(6, 182, 212, ${intensity * 0.3})` }}
          >
            <span className="text-xs font-bold text-white">{estado}</span>
            <span className="text-[10px] text-slate-400">{count}</span>
          </div>
        );
      })}
    </div>
  );
}

// ==================== DETAIL MODAL ====================

function ObraDetail({ obra, onClose }) {
  if (!obra) return null;

  const decisores = [
    { nome: "Carlos Roberto Silva", cargo: "Diretor de Engenharia", score: 10, status: "sugerido", fonte: "google_linkedin", linkedin: "#" },
    { nome: "Ana Maria Fernandes", cargo: "Gerente de Compras", score: 8, status: "sugerido", fonte: "receita_federal", linkedin: "#" },
    { nome: "Paulo Henrique Costa", cargo: "Coordenador de Obras", score: 7, status: "sugerido", fonte: "google_linkedin", linkedin: "#" },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4" onClick={onClose}>
      <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" />
      <div className="relative w-full max-w-3xl max-h-[90vh] overflow-y-auto bg-[#0f1225] border border-white/10 rounded-3xl shadow-2xl" onClick={(e) => e.stopPropagation()}>
        <div className="sticky top-0 z-10 flex items-center justify-between p-6 bg-[#0f1225]/95 backdrop-blur border-b border-white/5">
          <div className="flex items-center gap-4">
            <ScoreBadge score={obra.score_oportunidade} size="lg" />
            <div>
              <h2 className="text-lg font-bold text-white">{obra.titulo}</h2>
              <p className="text-sm text-slate-400 flex items-center gap-1"><MapPin size={12} /> {obra.cidade} - {obra.estado}</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-slate-400">
            <X size={18} />
          </button>
        </div>

        <div className="p-6 space-y-6">
          {/* Info Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {[
              { label: "Tipo", value: obra.tipo, color: "text-cyan-400" },
              { label: "Fase", value: obra.fase, color: "text-amber-400" },
              { label: "Porte", value: obra.porte, color: "text-purple-400" },
              { label: "Valor Est.", value: formatCurrency(obra.valor_estimado), color: "text-emerald-400" },
            ].map((item, i) => (
              <div key={i} className="bg-white/5 rounded-xl p-3 text-center">
                <p className="text-[10px] text-slate-500 uppercase tracking-wider">{item.label}</p>
                <p className={`text-sm font-semibold capitalize ${item.color}`}>{item.value}</p>
              </div>
            ))}
          </div>

          {/* Empresa */}
          {obra.empresa_nome && (
            <div className="bg-white/5 rounded-xl p-4">
              <h3 className="text-xs uppercase tracking-wider text-slate-500 mb-3">Empresa</h3>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-500/20 to-blue-500/20 flex items-center justify-center">
                  <Building2 size={18} className="text-cyan-400" />
                </div>
                <div>
                  <p className="text-white font-medium">{obra.empresa_nome}</p>
                  <div className="flex gap-3 mt-1">
                    <span className="text-[11px] text-slate-400 flex items-center gap-1"><Mail size={10} /> contato@empresa.com</span>
                    <span className="text-[11px] text-slate-400 flex items-center gap-1"><Phone size={10} /> (11) 3456-7890</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Decisores Sugeridos */}
          <div>
            <h3 className="text-xs uppercase tracking-wider text-slate-500 mb-3">Decisores Sugeridos</h3>
            <div className="space-y-2">
              {decisores.map((d, i) => (
                <div key={i} className="flex items-center justify-between p-3 rounded-xl bg-white/5 border border-white/5 hover:border-indigo-500/30 transition-all">
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-full bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-white text-xs font-bold">
                      {d.nome.split(" ").map((n) => n[0]).slice(0, 2).join("")}
                    </div>
                    <div>
                      <p className="text-sm text-white font-medium">{d.nome}</p>
                      <p className="text-[11px] text-slate-400">{d.cargo}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    {d.linkedin && (
                      <a href={d.linkedin} className="p-1.5 rounded-lg bg-blue-500/10 text-blue-400 hover:bg-blue-500/20">
                        <Linkedin size={14} />
                      </a>
                    )}
                    <button className="p-1.5 rounded-lg bg-emerald-500/10 text-emerald-400 hover:bg-emerald-500/20">
                      <CheckCircle size={14} />
                    </button>
                    <button className="p-1.5 rounded-lg bg-red-500/10 text-red-400 hover:bg-red-500/20">
                      <XCircle size={14} />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Actions */}
          <div className="flex gap-3">
            <button className="flex-1 py-3 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-500 text-white font-semibold text-sm hover:opacity-90 transition-opacity">
              Iniciar Prospecção
            </button>
            <button className="px-5 py-3 rounded-xl bg-white/5 text-slate-300 text-sm hover:bg-white/10 transition-colors border border-white/10">
              Descartar
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

// ==================== MAIN APP ====================

export default function ObraHunterDashboard() {
  const [tab, setTab] = useState("dashboard");
  const [selectedObra, setSelectedObra] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterOpen, setFilterOpen] = useState(false);
  const [liveCount, setLiveCount] = useState(MOCK_STATS.total_obras);

  // Simular contador ao vivo
  useEffect(() => {
    const interval = setInterval(() => {
      setLiveCount((c) => c + Math.floor(Math.random() * 3));
    }, 8000);
    return () => clearInterval(interval);
  }, []);

  const filteredObras = MOCK_OBRAS.filter(
    (o) => !searchTerm || o.titulo.toLowerCase().includes(searchTerm.toLowerCase()) ||
      o.cidade.toLowerCase().includes(searchTerm.toLowerCase()) ||
      o.empresa_nome?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const NAV_ITEMS = [
    { id: "dashboard", icon: BarChart3, label: "Dashboard" },
    { id: "obras", icon: Building2, label: "Obras" },
    { id: "alertas", icon: Bell, label: "Alertas" },
    { id: "buscas", icon: Zap, label: "Automação" },
  ];

  return (
    <div className="min-h-screen bg-[#0a0e1a] text-slate-300" style={{ fontFamily: "'Inter', 'DM Sans', system-ui, sans-serif" }}>
      {/* SIDEBAR */}
      <aside className="fixed left-0 top-0 bottom-0 w-[220px] bg-[#0f1225] border-r border-white/5 flex flex-col z-40">
        <div className="p-5 border-b border-white/5">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-cyan-400 to-blue-600 flex items-center justify-center">
              <Building2 size={18} className="text-white" />
            </div>
            <div>
              <h1 className="text-white font-bold text-sm tracking-tight">ObraHunter</h1>
              <p className="text-[10px] text-slate-500">Prospecção automática</p>
            </div>
          </div>
        </div>

        {/* Live indicator */}
        <div className="mx-4 mt-4 p-3 rounded-xl bg-emerald-500/5 border border-emerald-500/20">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span className="text-[11px] text-emerald-400 font-medium">Buscando ao vivo</span>
          </div>
          <p className="text-lg font-bold text-white mt-1">{formatNumber(liveCount)} <span className="text-xs font-normal text-slate-500">obras</span></p>
        </div>

        <nav className="flex-1 p-3 mt-2">
          {NAV_ITEMS.map((item) => (
            <button
              key={item.id}
              onClick={() => setTab(item.id)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm transition-all mb-1 ${
                tab === item.id
                  ? "bg-cyan-500/10 text-cyan-400 font-medium"
                  : "text-slate-400 hover:bg-white/5 hover:text-white"
              }`}
            >
              <item.icon size={17} />
              {item.label}
              {item.id === "alertas" && (
                <span className="ml-auto bg-red-500 text-white text-[9px] font-bold w-4 h-4 rounded-full flex items-center justify-center">
                  {MOCK_STATS.alertas_hoje}
                </span>
              )}
            </button>
          ))}
        </nav>

        <div className="p-4 border-t border-white/5">
          <button className="w-full flex items-center gap-2 px-3 py-2 rounded-xl text-xs text-slate-500 hover:bg-white/5 hover:text-slate-300 transition-all">
            <Settings size={14} />
            Configurações
          </button>
        </div>
      </aside>

      {/* MAIN */}
      <main className="ml-[220px] min-h-screen">
        {/* Header */}
        <header className="sticky top-0 z-30 bg-[#0a0e1a]/80 backdrop-blur-xl border-b border-white/5 px-6 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-white font-bold text-lg capitalize">{NAV_ITEMS.find((n) => n.id === tab)?.label}</h2>
              <p className="text-xs text-slate-500">Atualizado agora · {new Date().toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" })}</p>
            </div>
            <div className="flex items-center gap-3">
              <div className="relative">
                <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
                <input
                  type="text"
                  placeholder="Buscar obras, empresas..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-64 bg-white/5 border border-white/10 rounded-xl pl-9 pr-4 py-2 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500/50 transition-colors"
                />
              </div>
              <button className="relative p-2.5 rounded-xl bg-white/5 text-slate-400 hover:text-white border border-white/10">
                <Bell size={17} />
                <span className="absolute -top-0.5 -right-0.5 bg-red-500 text-white text-[8px] font-bold w-3.5 h-3.5 rounded-full flex items-center justify-center">
                  {MOCK_STATS.alertas_hoje}
                </span>
              </button>
            </div>
          </div>
        </header>

        <div className="p-6">
          {/* ==================== DASHBOARD TAB ==================== */}
          {tab === "dashboard" && (
            <div className="space-y-6">
              {/* Stats Row */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <StatCard icon={Building2} label="Total de Obras" value={formatNumber(liveCount)} sub={`+${MOCK_STATS.obras_novas_hoje} hoje`} />
                <StatCard icon={Zap} label="Buscas Ativas" value={MOCK_STATS.buscas_ativas} sub="Rodando 24/7" accent />
                <StatCard icon={UserCheck} label="Decisores" value={`${MOCK_STATS.decisores_validados}/${MOCK_STATS.total_decisores}`} sub="Validados" />
                <StatCard icon={Star} label="Score Médio" value={MOCK_STATS.score_medio.toFixed(1)} sub="De 0 a 10" />
              </div>

              {/* Main Grid */}
              <div className="grid grid-cols-12 gap-4">
                {/* Timeline */}
                <div className="col-span-12 md:col-span-4 bg-[#1a1f35]/80 border border-white/5 rounded-2xl p-5">
                  <h3 className="text-xs uppercase tracking-wider text-slate-500 mb-4">Obras encontradas · 7 dias</h3>
                  <MiniChart data={MOCK_STATS.timeline_semanal} />
                  <div className="flex justify-between mt-3">
                    <span className="text-[10px] text-slate-500">Total semana</span>
                    <span className="text-sm font-bold text-white">{MOCK_STATS.obras_novas_semana}</span>
                  </div>
                </div>

                {/* Funil */}
                <div className="col-span-12 md:col-span-4 bg-[#1a1f35]/80 border border-white/5 rounded-2xl p-5">
                  <h3 className="text-xs uppercase tracking-wider text-slate-500 mb-4">Pipeline de Conversão</h3>
                  <FunnelBar data={MOCK_STATS.obras_por_status} />
                </div>

                {/* Fontes */}
                <div className="col-span-12 md:col-span-4 bg-[#1a1f35]/80 border border-white/5 rounded-2xl p-5">
                  <h3 className="text-xs uppercase tracking-wider text-slate-500 mb-4">Fontes de Dados</h3>
                  <SourceBreakdown data={MOCK_STATS.obras_por_fonte} />
                </div>

                {/* Mapa de estados */}
                <div className="col-span-12 md:col-span-5 bg-[#1a1f35]/80 border border-white/5 rounded-2xl p-5">
                  <h3 className="text-xs uppercase tracking-wider text-slate-500 mb-4">Distribuição por Estado</h3>
                  <StateMap data={MOCK_STATS.obras_por_estado} />
                </div>

                {/* Alertas recentes */}
                <div className="col-span-12 md:col-span-7 bg-[#1a1f35]/80 border border-white/5 rounded-2xl p-5">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-xs uppercase tracking-wider text-slate-500">Alertas Recentes</h3>
                    <Bell size={14} className="text-amber-400" />
                  </div>
                  <div className="space-y-2">
                    {MOCK_ALERTAS.map((a) => <AlertCard key={a.id} alerta={a} />)}
                  </div>
                </div>
              </div>

              {/* Top Obras */}
              <div>
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-white font-semibold">Melhores Oportunidades</h3>
                  <button onClick={() => setTab("obras")} className="text-xs text-cyan-400 hover:text-cyan-300 flex items-center gap-1">
                    Ver todas <ChevronRight size={12} />
                  </button>
                </div>
                <div className="grid gap-3">
                  {MOCK_OBRAS.slice(0, 4).map((obra) => (
                    <ObraCard key={obra.id} obra={obra} onClick={setSelectedObra} />
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* ==================== OBRAS TAB ==================== */}
          {tab === "obras" && (
            <div className="space-y-4">
              {/* Filters Bar */}
              <div className="flex items-center gap-3 flex-wrap">
                <button
                  onClick={() => setFilterOpen(!filterOpen)}
                  className="flex items-center gap-2 px-4 py-2 rounded-xl bg-white/5 border border-white/10 text-sm text-slate-300 hover:border-cyan-500/30"
                >
                  <Filter size={14} /> Filtros <ChevronDown size={12} />
                </button>
                {["Todos", "Novos", "Enriquecidos", "Com Contato", "Em Prospecção"].map((f, i) => (
                  <button
                    key={f}
                    className={`px-3 py-1.5 rounded-lg text-xs transition-all ${
                      i === 0 ? "bg-cyan-500/20 text-cyan-400 border border-cyan-500/30" : "bg-white/5 text-slate-400 hover:text-white border border-transparent"
                    }`}
                  >
                    {f}
                  </button>
                ))}
                <span className="ml-auto text-xs text-slate-500">{filteredObras.length} resultados</span>
              </div>

              {filterOpen && (
                <div className="grid grid-cols-4 gap-4 p-5 bg-[#1a1f35]/80 rounded-2xl border border-white/5">
                  <div>
                    <label className="text-[10px] uppercase text-slate-500 tracking-wider mb-2 block">Estado</label>
                    <select className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-white">
                      <option value="">Todos</option>
                      {Object.keys(MOCK_STATS.obras_por_estado).map((e) => <option key={e} value={e}>{e}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="text-[10px] uppercase text-slate-500 tracking-wider mb-2 block">Tipo</label>
                    <select className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-white">
                      <option value="">Todos</option>
                      {Object.keys(TIPO_COLORS).map((t) => <option key={t} value={t}>{t}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="text-[10px] uppercase text-slate-500 tracking-wider mb-2 block">Score Mínimo</label>
                    <input type="range" min="0" max="10" step="0.5" defaultValue="0" className="w-full" />
                  </div>
                  <div>
                    <label className="text-[10px] uppercase text-slate-500 tracking-wider mb-2 block">Fonte</label>
                    <select className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-white">
                      <option value="">Todas</option>
                      <option value="google_maps">Google Maps</option>
                      <option value="diario_oficial">Diário Oficial</option>
                      <option value="licitacao">Licitação</option>
                      <option value="construtora">Construtora</option>
                    </select>
                  </div>
                </div>
              )}

              <div className="grid gap-3">
                {filteredObras.map((obra) => (
                  <ObraCard key={obra.id} obra={obra} onClick={setSelectedObra} />
                ))}
              </div>
            </div>
          )}

          {/* ==================== ALERTAS TAB ==================== */}
          {tab === "alertas" && (
            <div className="space-y-6">
              <div className="grid grid-cols-3 gap-4">
                <StatCard icon={Bell} label="Alertas Hoje" value={MOCK_STATS.alertas_hoje} accent />
                <StatCard icon={TrendingUp} label="Score Médio Alertas" value="8.4" sub="Oportunidades quentes" />
                <StatCard icon={Activity} label="Taxa de Conversão" value="12%" sub="Alertas → Contato" />
              </div>

              <div>
                <h3 className="text-white font-semibold mb-4">Oportunidades Recentes</h3>
                <div className="space-y-3">
                  {MOCK_ALERTAS.map((a) => (
                    <div key={a.id} className="flex items-center gap-4 p-4 rounded-2xl bg-[#1a1f35]/80 border border-amber-500/10 hover:border-amber-500/30 transition-all cursor-pointer">
                      <ScoreBadge score={a.score} />
                      <div className="flex-1">
                        <h4 className="text-white font-medium">{a.titulo}</h4>
                        <p className="text-xs text-slate-400 mt-0.5">{a.motivo}</p>
                        <p className="text-[11px] text-slate-500 mt-1">{a.cidade} · {a.tempo}</p>
                      </div>
                      <div className="flex gap-2">
                        <button className="px-3 py-1.5 rounded-lg bg-cyan-500/10 text-cyan-400 text-xs font-medium hover:bg-cyan-500/20">
                          Ver Detalhes
                        </button>
                        <button className="px-3 py-1.5 rounded-lg bg-emerald-500/10 text-emerald-400 text-xs font-medium hover:bg-emerald-500/20">
                          Prospectar
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* ==================== AUTOMAÇÃO TAB ==================== */}
          {tab === "buscas" && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-400">
                    Buscas automáticas rodando 24/7. O robô encontra obras e te alerta.
                  </p>
                </div>
                <button className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-500 text-white text-sm font-semibold hover:opacity-90 flex items-center gap-2">
                  <Zap size={15} /> Nova Busca
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {MOCK_BUSCAS.map((b) => (
                  <BuscaCard key={b.id} busca={b} />
                ))}
              </div>

              {/* Create form hint */}
              <div className="bg-[#1a1f35]/60 border border-dashed border-white/10 rounded-2xl p-8 text-center">
                <Zap size={32} className="text-cyan-400 mx-auto mb-3 opacity-50" />
                <p className="text-slate-400 text-sm">Configure novas buscas automáticas para expandir sua prospecção</p>
                <p className="text-slate-500 text-xs mt-1">Defina filtros, frequência e canais de alerta</p>
              </div>
            </div>
          )}
        </div>
      </main>

      {/* DETAIL MODAL */}
      {selectedObra && (
        <ObraDetail obra={selectedObra} onClose={() => setSelectedObra(null)} />
      )}

      {/* IMPORT FONT */}
      <style>{`@import url('https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,300;0,9..40,400;0,9..40,500;0,9..40,600;0,9..40,700&family=Inter:wght@300;400;500;600;700&display=swap');`}</style>
    </div>
  );
}
